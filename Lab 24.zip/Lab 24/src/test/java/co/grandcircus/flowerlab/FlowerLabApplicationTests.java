package co.grandcircus.flowerlab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlowerLabApplicationTests {

	@Test
	void contextLoads() {
	}

}
