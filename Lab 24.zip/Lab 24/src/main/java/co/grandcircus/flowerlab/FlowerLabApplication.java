package co.grandcircus.flowerlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlowerLabApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlowerLabApplication.class, args);
	}

}
