package co.grandcircus.flowerlab;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import co.grandcircus.flowerlab.dao.FlowerRepository;

@Controller
public class flowerController {
	@Autowired
	private FlowerRepository dao;
	
	@RequestMapping
	public static String home() {
		
		return "home";
	}
}
