package co.grandcircus.flowerlab.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import co.grandcircus.flowerlab.entity.Flower;

public interface FlowerRepository extends JpaRepository<Flower, Long> {

}